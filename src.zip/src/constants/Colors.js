export default {

blue : "#FD5E53",
grey : "#b3b3b3",
activeTintColor :"007efa",
inactiveTintColor : "#b3b3b3"
}